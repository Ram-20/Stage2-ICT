package com.cognizant.portfolioManagement.model;


import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class PortfolioDetails {
	
	
	private String stockName;
	
	
	@NotNull(message = "{required.text}")
	@Min(value = 1, message = "{min.text}")
	private Integer noOfShares;
	
	
	
	private float netWorth;
	
		

	public Integer getNoOfShares() {
		return noOfShares;
	}

	public void setNoOfShares(Integer noOfShares) {
		this.noOfShares = noOfShares;
	}

	

	public float getNetWorth() {
		return netWorth;
	}

	public void setNetWorth(float netWorth) {
		this.netWorth = netWorth;
	}

	public String getStockName() {
		return stockName;
	}

	public void setStockName(String stockName) {
		this.stockName = stockName;
	}

	

		

}
