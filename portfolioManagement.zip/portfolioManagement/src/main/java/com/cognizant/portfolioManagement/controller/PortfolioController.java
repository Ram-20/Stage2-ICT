package com.cognizant.portfolioManagement.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.portfolioManagement.model.PortfolioDetails;
import com.cognizant.portfolioManagement.service.PortfolioService;


@Controller
public class PortfolioController {
	
	@Autowired
	private PortfolioService portfolioService;
	
	
	
	@ModelAttribute("stockList")
	public List populateStockList(){
		
		List stockList = new ArrayList();
		
		stockList.add("VM Pharma");
		stockList.add("Vishwa Properties");
		stockList.add("JJ Automobiles");
		
		return stockList;
		
	}
	
	
	@RequestMapping("/portfolioForm")
	public String displayPortfolioForm(Model theModel) {
		
		// create a student object
		PortfolioDetails portfolioDetails = new PortfolioDetails();
				
				// add student object to the model
				theModel.addAttribute("portfolio", portfolioDetails);
				
				return "portfolioform";
		
		
	}
	
	@RequestMapping("/calculateNetworth")
    public String calculateNetworth(@Valid @ModelAttribute("portfolio") PortfolioDetails portfolioDetails,BindingResult theBindingResult,ModelMap map)
    {
    	if(theBindingResult.hasErrors())
    	{
    		return "portfolioform";
    	}
    	else
    	{	map.addAttribute("portfolio", portfolioService.calculateNetworth(portfolioDetails));
    		
    		return "networth";
    	}
    }
}


