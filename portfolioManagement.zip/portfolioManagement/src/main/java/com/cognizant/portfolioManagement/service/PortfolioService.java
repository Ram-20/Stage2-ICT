package com.cognizant.portfolioManagement.service;

import com.cognizant.portfolioManagement.model.PortfolioDetails;

public interface PortfolioService {
	
	public float calculateNetworth(PortfolioDetails portfolioDetails) ;

}
