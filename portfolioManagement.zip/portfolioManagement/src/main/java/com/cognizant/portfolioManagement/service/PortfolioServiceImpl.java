package com.cognizant.portfolioManagement.service;

import org.springframework.stereotype.Service;

import com.cognizant.portfolioManagement.model.PortfolioDetails;


@Service
public class PortfolioServiceImpl implements PortfolioService {
	
	
	public float calculateNetworth(PortfolioDetails portfolioDetails) {
		
		String stockName = portfolioDetails.getStockName();
		
		int noOfShares = portfolioDetails.getNoOfShares();
		
		float sharePrice = 0.0f;
		
		float networth = 0.0f;
		
		if(stockName.equals("VM Pharma")) {
			
			sharePrice = 785;
		}
		if(stockName.equals("Vishwa Properties")) {
			
			sharePrice = 55;
		}	
		if(stockName.equals("JJ Automobiles")) {
			
			sharePrice = 45;
		}
		
		networth = noOfShares * sharePrice;
		
		return networth;
	}

}
